
package model;


public abstract class Menu {
    public abstract void execute();

    public void run() {
        execute();
    } 
}